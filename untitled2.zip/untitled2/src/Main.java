enum AnimalType {
    MAMMAL, BIRD, REPTILE, AMPHIBIAN, FISH
}

abstract class Animal {
    private String name;
    private int age;
    private AnimalType type;
    private String habitat;

    public Animal(String name, int age, AnimalType type, String habitat) {
        this.name = name;
        this.age = age;
        this.type = type;
        this.habitat = habitat;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public int getAge() {
        return age;
    }

    public void setAge(int age) {
        this.age = age;
    }

    public AnimalType getType() {
        return type;
    }

    public void setType(AnimalType type) {
        this.type = type;
    }

    public String getHabitat() {
        return habitat;
    }

    public void setHabitat(String habitat) {
        this.habitat = habitat;
    }

    public abstract void makeSound();
}

class Dog extends Animal {
    private String breed;

    public Dog(String name, int age, String breed, String habitat) {
        super(name, age, AnimalType.MAMMAL, habitat);
        this.breed = breed;
    }

    public String getBreed() {
        return breed;
    }

    public void setBreed(String breed) {
        this.breed = breed;
    }

    public void makeSound() {
        System.out.println("Woof!");
    }

    public void fetch() {
        System.out.println("Fetching the ball!");
    }
}

class Parrot extends Animal implements Pet, Bird {
    private String color;

    public Parrot(String name, int age, String color, String habitat) {
        super(name, age, AnimalType.BIRD, habitat);
        this.color = color;
    }

    public String getColor() {
        return color;
    }

    public void setColor(String color) {
        this.color = color;
    }

    public void makeSound() {
        System.out.println("Squawk!");
    }

    public void playWith() {
        System.out.println("Playing with the parrot!");
    }

    public void fly() {
        System.out.println("The parrot is flying!");
    }
}

interface Pet {
    public abstract void playWith();
}

interface Bird {
    public abstract void fly();
}

public class Main {
    public static void main(String[] args) {
        Dog dog1 = new Dog("Rex", 3, "Labrador", "House");
        Dog dog2 = new Dog("Buddy", 5, "Golden Retriever", "Backyard");

        Parrot parrot1 = new Parrot("Polly", 2, "Green", "Cage");
        Parrot parrot2 = new Parrot("Rio", 1, "Blue", "Tree");

        dog1.makeSound();
        dog1.fetch();

        dog2.makeSound();

        parrot1.makeSound();
        parrot1.playWith();
        parrot1.fly();

        parrot2.makeSound();
        parrot2.playWith();
        parrot2.fly();
    }
}
